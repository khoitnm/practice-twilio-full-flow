/**
 * The video room state which is used in UI
 */
export default interface VideoRoomState {
  roomSid: string;
  uniqueName: string;
  state: string;
}