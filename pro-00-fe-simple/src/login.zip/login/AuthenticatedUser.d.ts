interface AuthenticatedUser {
    username: string,
    twilioAccessToken: string
}